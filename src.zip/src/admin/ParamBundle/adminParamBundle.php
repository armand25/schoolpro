<?php

namespace admin\ParamBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class adminParamBundle extends Bundle
{
}
