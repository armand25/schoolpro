<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of TypeSexe
 *
 * @author Administrateur
 */
namespace admin\UserBundle\Types;

class TypeSexe {
    const MASCULIN = 1;
    
    const FEMININ = 2;
}
