<?php

namespace admin\SiteBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class adminSiteBundle extends Bundle
{
}
