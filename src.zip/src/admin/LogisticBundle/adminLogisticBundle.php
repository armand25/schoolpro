<?php

namespace admin\LogisticBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class adminLogisticBundle extends Bundle
{
}
