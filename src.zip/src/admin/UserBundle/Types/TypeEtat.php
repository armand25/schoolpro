<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of TypeEtat
 *
 * @author edmond
 */

namespace admin\UserBundle\Types;

class TypeEtat {
    
    const ACTIF = 1;
    
    const INACTIF = 2;
    
    const SUPPRIME = 3;
    
    const BLOQUE = 4;
    
    const APRODUIRE = 0;
}
