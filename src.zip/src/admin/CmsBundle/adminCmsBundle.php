<?php

namespace admin\CmsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class adminCmsBundle extends Bundle
{
}
