<?php

namespace admin\EconomatBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class adminEconomatBundle extends Bundle
{
}
