<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of TypeEtat
 *
 * @author edmond
 */

namespace admin\UserBundle\Types;

class TypeProfil{
    
    const PROFIL_UTILISATEUR = 1;
    
    const PROFIL_ABONNE = 2;
    
    const PROFIL_PARENT_ELEVE = 4;
    const PROFIL_ELEVE = 5;
    const PROFIL_ENSEIGANT = 3;
    
}
