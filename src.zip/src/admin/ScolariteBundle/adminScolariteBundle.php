<?php

namespace admin\ScolariteBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class adminScolariteBundle extends Bundle
{
}
