<?php

namespace admin\MessagerieBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class adminMessagerieBundle extends Bundle
{
}
